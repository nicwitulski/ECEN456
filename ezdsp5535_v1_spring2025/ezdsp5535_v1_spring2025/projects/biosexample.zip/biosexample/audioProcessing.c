/*
 *  Copyright 2010 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *
 */
/***************************************************************************/
/*                                                                         */
/*     H E L L O . C                                                       */
/*                                                                         */
/*     Basic LOG event operation from main.                                */
/*                                                                         */
/***************************************************************************/

#include <std.h>

#include <log.h>

#include "hellocfg.h"
#include "ezdsp5535.h"
#include "stdint.h"
#include "aic3204.h"
#include "ezdsp5535_i2s.h"
#include "csl_i2s.h"

extern CSL_I2sHandle   hI2s;

int16_t leftSample;
int16_t rightSample;


void audioProcessingInit(void)
{
}


void HWI_I2S_Rx(void)
{
	/*
	 * called at sampled rate i.e. 48kHz
	 */
	leftSample = hI2s->hwRegs->I2SRXLT1;
	rightSample = hI2s->hwRegs->I2SRXRT1;
}

void HWI_I2S_Tx(void)
{
	/*
	 * called at sampled rate i.e. 48kHz
	 */
	hI2s->hwRegs->I2STXLT1 = leftSample;
	hI2s->hwRegs->I2STXRT1 = rightSample;
}

